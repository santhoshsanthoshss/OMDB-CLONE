import React from "react";
import "../css/Loaderfake.css";
const Loaderforfake = () => {
  return (
    <div className="loderstyle">
      <span class="loader"></span>
    </div>
  );
};

export default Loaderforfake;
